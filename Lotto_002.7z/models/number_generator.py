class NumberGenerator:
    def __init__(self):
        pass

    def generate_numbers(self):
        # 번호 생성 알고리즘 작성
        pass
