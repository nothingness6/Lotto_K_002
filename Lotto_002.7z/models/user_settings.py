class UserSettings:
    def __init__(self):
        pass

    def save_settings(self, settings):
        # 설정 저장 로직 작성
        pass

    def load_settings(self):
        # 설정 불러오기 로직 작성
        pass
