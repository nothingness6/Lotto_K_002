class DataStorage:
    def __init__(self):
        pass

    def save_data(self, data):
        # 데이터 저장 로직 작성
        pass

    def load_data(self):
        # 데이터 불러오기 로직 작성
        pass
