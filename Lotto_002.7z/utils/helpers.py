def some_helper_function():
    # 헬퍼 함수 로직 작성
    pass
