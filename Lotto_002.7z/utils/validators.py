def validate_number(number):
    # 번호 검증 로직 작성
    pass
